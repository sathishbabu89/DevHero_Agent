import React from 'react';
import { useAuth } from '../context/AuthContext';
import LoginForm from '../components/LoginForm/LoginForm';

const Login = () => {
  const { login, loading } = useAuth();

  const handleLogin = async (email, password) => {
    return await login(email, password);
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      padding: '1rem'
    }}>
      <LoginForm 
        onSubmit={handleLogin} 
        loading={loading}
      />
    </div>
  );
};

export default Login;