import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Home = () => {
  const { isAuthenticated, user } = useAuth();

  return (
    <div style={{ padding: '2rem' }}>
      <h1>Welcome to Our App</h1>
      {isAuthenticated ? (
        <div>
          <p>Hello, {user?.name}! You are logged in.</p>
          <Link to="/dashboard">Go to Dashboard</Link>
        </div>
      ) : (
        <div>
          <p>Please log in to access the dashboard.</p>
          <Link to="/login">Login</Link>
        </div>
      )}
    </div>
  );
};

export default Home;