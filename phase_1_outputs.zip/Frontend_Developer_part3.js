import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import styles from './LoginForm.module.css';

const LoginForm = ({ onSubmit, loading, error }) => {
  const initialValues = {
    email: '',
    password: ''
  };

  const validationSchema = Yup.object({
    email: Yup.string()
      .email('Invalid email address')
      .required('Email is required'),
    password: Yup.string()
      .min(6, 'Password must be at least 6 characters')
      .required('Password is required')
  });

  const handleSubmit = async (values, { setSubmitting, resetForm }) => {
    const result = await onSubmit(values.email, values.password);
    if (result.success) {
      resetForm();
    }
    setSubmitting(false);
  };

  return (
    <div className={styles.loginFormContainer}>
      <h2 className={styles.title}>Welcome Back</h2>
      <p className={styles.subtitle}>Please sign in to your account</p>
      
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        {({ isSubmitting, errors, touched }) => (
          <Form className={styles.form}>
            {error && (
              <div className={styles.errorMessage}>
                {error}
              </div>
            )}
            
            <div className={styles.formGroup}>
              <label htmlFor="email" className={styles.label}>
                Email Address
              </label>
              <Field
                type="email"
                id="email"
                name="email"
                className={`${styles.input} ${
                  errors.email && touched.email ? styles.inputError : ''
                }`}
                placeholder="Enter your email"
              />
              <ErrorMessage
                name="email"
                component="div"
                className={styles.errorText}
              />
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="password" className={styles.label}>
                Password
              </label>
              <Field
                type="password"
                id="password"
                name="password"
                className={`${styles.input} ${
                  errors.password && touched.password ? styles.inputError : ''
                }`}
                placeholder="Enter your password"
              />
              <ErrorMessage
                name="password"
                component="div"
                className={styles.errorText}
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting || loading}
              className={styles.submitButton}
            >
              {loading || isSubmitting ? (
                <span className={styles.loadingText}>
                  Signing In...
                </span>
              ) : (
                'Sign In'
              )}
            </button>
          </Form>
        )}
      </Formik>
      
      <div className={styles.demoCredentials}>
        <p className={styles.demoTitle}>Demo Credentials:</p>
        <p>Email: user@example.com</p>
        <p>Password: password</p>
      </div>
    </div>
  );
};

export default LoginForm;